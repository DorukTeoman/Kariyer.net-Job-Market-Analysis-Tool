import requests
from bs4 import BeautifulSoup
import time
import pandas as pd

def normalize_text(text):
    """
    SADECE FİLTRELEME için metni normalize eder.
    Tüm 'İ/i/I/ı' varyasyonlarını 'i' harfine dönüştürür.
    """
    if not isinstance(text, str):
        return ""
    text = text.replace('İ', 'i').replace('I', 'i')
    text = text.lower()
    text = text.replace('ı', 'i')
    replacements = {'ş': 's', 'ğ': 'g', 'ü': 'u', 'ö': 'o', 'ç': 'c'}
    for tr_char, en_char in replacements.items():
        text = text.replace(tr_char, en_char)
    return text.strip()

print("--- Kariyer.net İş Piyasası Analiz Aracı ---")
title_keyword = input("Hangi pozisyonu arıyorsunuz? (örn: yazılım, hemşire, grafiker): ")
location_keyword = input("Hangi konumda arıyorsunuz? (örn: istanbul, ankara / Tüm Türkiye için [Enter] basın): ")

base_url = "https://www.kariyer.net/is-ilanlari"
search_params = {}
filename_parts = []

filter_title = normalize_text(title_keyword)
search_params['kw'] = title_keyword
filename_parts.append(filter_title.replace(' ', '-'))

filter_location = normalize_text(location_keyword)
if location_keyword:
    search_params['kw'] = f"{title_keyword} {location_keyword}"
    filename_parts.append(filter_location.replace(' ', '-'))
else:
    filename_parts.append("tum-turkiye")

filename_base = f"ilanlar_{'_'.join(filename_parts)}"
csv_filename = f"{filename_base}.csv"
excel_filename = f"{filename_base}.xlsx"

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)"}
job_list = []

try:
    print(f"\n'{title_keyword}' - '{location_keyword or 'Tüm Türkiye'}' için arama yapılıyor...")
    response = requests.get(base_url, headers=headers, params=search_params)
    print(f"Hedef URL: {response.url}")

    if response.status_code == 200:
        print("Bağlantı başarılı!")
        soup = BeautifulSoup(response.content, "html.parser")
        job_cards = soup.find_all('div', attrs={"data-test": "ad-card"})
        
        if not job_cards:
            print("Uyarı: Bu arama için ilan kartları bulunamadı. Lütfen anahtar kelimelerinizi kontrol edin.")
            exit()
            
        print(f"Toplam {len(job_cards)} adet iş ilanı bulundu. Filtreleme ve veri çekme başlıyor...")
        
        filtered_count = 0
        
        for card in job_cards:
            sponsored_badge = card.find('p', attrs={"data-test": "ad-card-sponsored-item-title"})
            if sponsored_badge:
                continue 

            title_element = card.find('span', attrs={"data-test": "ad-card-title"})
            job_title = title_element.get_text(strip=True) if title_element else "N/A"
            
            clean_job_title = normalize_text(job_title)
            if filter_title not in clean_job_title:
                continue 
            
            company_element = card.find('span', attrs={"data-test": "subtitle"})
            company_name = company_element.get_text(strip=True) if company_element else "N/A"
            
            location_element = card.find('span', attrs={"data-test": "location"})
            location_text = location_element.get_text(strip=True) if location_element else "N/A"

            if location_keyword:
                clean_location_text = normalize_text(location_text)
                if filter_location not in clean_location_text:
                    continue 

            link_element = card.find('a', attrs={"data-test": "ad-card-item"})
            link = "https://www.kariyer.net" + link_element['href'] if link_element and 'href' in link_element.attrs else "N/A"

            job_data = {"title": job_title, "company": company_name, "location": location_text, "link": link}
            job_list.append(job_data)
            filtered_count += 1
            
        print(f"\nToplam {filtered_count} adet filtrelenmiş ilan başarıyla çekildi.")

        if len(job_list) > 0:
            print("Veriler Pandas DataFrame'e dönüştürülüyor...")
            df = pd.DataFrame(job_list)
            
            print("\n" + "="*30)
            print("       VERİ ANALİZİ")
            print("="*30)

            company_counts = df[~df['company'].isin(['N/A', 'Gizli'])]['company'].value_counts()
            
            print("\n--- En Çok İlan Veren 5 Şirket ---")
            if company_counts.empty:
                print("Yeterli şirket verisi bulunamadı (Tümü 'Gizli' olabilir).")
            else:
                print(company_counts.head(5))

            location_counts = df['location'].value_counts()
            
            print("\n--- İlanların Konum Dağılımı (İlk 10) ---")
            if location_counts.empty:
                print("Konum verisi bulunamadı.")
            else:
                print(location_counts.head(10))
            
            print("\n" + "="*30 + "\n")

            print("Analiz tamamlandı, veriler dosyalara kaydediliyor...")
            df.to_csv(csv_filename, index=False, encoding='utf-8-sig')
            print(f"Veriler başarıyla '{csv_filename}' dosyasına kaydedildi.")
            
            df.to_excel(excel_filename, index=False)
            print(f"Veriler başarıyla '{excel_filename}' dosyasına kaydedildi.")
            
        else:
            print("Filtreleme sonrası analiz edilecek veya kaydedilecek hiç ilan bulunamadı.")
            
    else:
        print(f"Hata! Sayfaya bağlanılamadı. Status Code: {response.status_code}")
        
except requests.exceptions.RequestException as e:
    print(f"İstek sırasında bir hata oluştu: {e}")